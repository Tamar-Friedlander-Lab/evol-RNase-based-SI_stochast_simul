#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys
import collections, pickle
from datetime import datetime
#from numba import jit
import pickle
from scipy.optimize import curve_fit
import matplotlib.ticker as mtick
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)

weight = [0.5, 0.265, 0.113, 0.122]



def data_To_Plot(input_Var):
    iter_ext_ind = input_Var

    # input data
    min_duration = 10
    d_iters = 10
    #output_dir = './data_fig_7'
    directory = './data_fig_7'

    #print(os.path.join(subdirectory))
    #iter_ext_ind = 62690 #80590, 33700, 62690
    if iter_ext_ind in [80590]:
        output_dir = directory+'/neutral' + "/" + '2022-11-12-15-57-44-13_dup'
    if iter_ext_ind in [33700, 65820]:
        output_dir = directory+'/non_comp_rnase-cross_mut' + "/" + '2022-11-12-15-57-44-13_dup'
    if iter_ext_ind in [62690]:
        output_dir = directory+'/splt_and_ext' + "/" + '2022-11-12-15-57-44-13_dup'

    with open(output_dir + '/analyze_extinct_group_all_iters_' + str(min_duration * 10) + '_dict.pkl', 'rb') as input:
        analyze_extinct_group_all_iters_dict = pickle.load(input)

    #for iter_ext_ind in [80590]:#analyze_extinct_group_all_iters_dict.keys():#[74280] :#[80590]:#
    # iter_ext_ind = 107880
    if 'ext_type' in analyze_extinct_group_all_iters_dict[iter_ext_ind][0]:

        #Extinction – cross in SLFmut

        mut_RNase = analyze_extinct_group_all_iters_dict[iter_ext_ind][0]['mut RNase']
        extinct_group = analyze_extinct_group_all_iters_dict[iter_ext_ind][0]['extinct_group']
        mut_iter = analyze_extinct_group_all_iters_dict[iter_ext_ind][0]['mut iter']

        with open(output_dir + '/tot_fitness_hap_orig_rnase_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            tot_fitness_hap_orig_rnase = pickle.load(input)

        with open(output_dir + '/tot_fitness_hap_mut_rnase_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            tot_fitness_hap_mut_rnase = pickle.load(input)

        with open(output_dir + '/tot_fitness_hap_cross_orig_rnase_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            tot_fitness_hap_cross_orig_rnase = pickle.load(input)
        #print (tot_fitness_hap_cross_orig_rnase)

        with open(output_dir + '/tot_fitness_hap_cross_mut_rnase_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            tot_fitness_hap_cross_mut_rnase = pickle.load(input)

        with open(output_dir + '/tot_num_hap_cross_orig_rnase_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            tot_num_hap_cross_orig_rnase = pickle.load(input)

        with open(output_dir + '/tot_num_hap_orig_rnase_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            tot_num_hap_orig_rnase = pickle.load(input)
        #print (tot_num_hap_orig_rnase)

        with open(output_dir + '/tot_num_hap_mut_rnase_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            tot_num_hap_mut_rnase = pickle.load(input)

        with open(output_dir + '/tot_num_hap_cross_mut_rnase_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(min_duration * 10) + '_.pkl', 'rb') as input:
            tot_num_hap_cross_mut_rnase = pickle.load(input)

        # temp
        if iter_ext_ind in [62690]:
            output_dir_temp = directory+'/splt_and_ext' + "/" + '2022-11-12-15-57-44-13'


            with open(output_dir_temp + '/tot_num_hap_cross_orig_rnase_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                tot_num_hap_cross_orig_rnase = pickle.load(input)
            print (tot_num_hap_cross_orig_rnase)


        #print (tot_fitness_hap_cross_orig_rnase)
        #print (tot_num_hap_cross_mut_rnase, '\n')

        sum_tot_num_hap_orig_rnase = {}
        sum_tot_num_hap_mut_rnase = {}
        sum_tot_num_hap_cross_orig_rnase = {}
        sum_tot_num_hap_cross_mut_rnase = {}

        for i, num_hap_orig_rnase_dict in tot_num_hap_orig_rnase.items():
            for iter_ind, num in num_hap_orig_rnase_dict.items():
                if not np.isnan(num):
                    if iter_ind not in sum_tot_num_hap_orig_rnase:
                        sum_tot_num_hap_orig_rnase[iter_ind] = 0
                    sum_tot_num_hap_orig_rnase[iter_ind] += num
        #print (tot_num_hap_orig_rnase)
        #print (sum_tot_num_hap_orig_rnase, '\n')

        for i, num_hap_mut_rnase_dict in tot_num_hap_mut_rnase.items():
            for iter_ind, num in num_hap_mut_rnase_dict.items():
                if not np.isnan(num):
                    if iter_ind not in sum_tot_num_hap_mut_rnase:
                        sum_tot_num_hap_mut_rnase[iter_ind] = 0
                    sum_tot_num_hap_mut_rnase[iter_ind] += num

        for i, num_hap_cross_orig_rnase in tot_num_hap_cross_orig_rnase.items():
            for iter_ind, num in num_hap_cross_orig_rnase.items():
                if not np.isnan(num):
                    if iter_ind not in sum_tot_num_hap_cross_orig_rnase:
                        sum_tot_num_hap_cross_orig_rnase[iter_ind] = 0
                    sum_tot_num_hap_cross_orig_rnase[iter_ind] += num

        for i, num_hap_cross_mut_rnase in tot_num_hap_cross_mut_rnase.items():
            for iter_ind, num in num_hap_cross_mut_rnase.items():
                if not np.isnan(num):
                    if iter_ind not in sum_tot_num_hap_cross_mut_rnase:
                        sum_tot_num_hap_cross_mut_rnase[iter_ind] = 0
                    sum_tot_num_hap_cross_mut_rnase[iter_ind] += num

        #print (sum_tot_num_hap_cross_mut_rnase)
        #print (sum_tot_num_hap_cross_orig_rnase)
        #print (sum_tot_num_hap_mut_rnase)
        #print (sum_tot_num_hap_orig_rnase, '\n')



        with open(output_dir + '/expected_num_change_orig_rnase_dict_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            expected_num_change_orig_rnase_dict = pickle.load(input)

        with open(output_dir + '/expected_num_change_mut_rnase_dict_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            expected_num_change_mut_rnase_dict = pickle.load(input)

        with open(output_dir + '/expected_num_change_cross_SLF_in_mut_dict_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            expected_num_change_cross_SLF_in_mut_dict = pickle.load(input)

        with open(output_dir + '/expected_num_change_cross_SLF_in_orig_dict_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            expected_num_change_cross_SLF_in_orig_dict = pickle.load(input)


        # temp
        if iter_ext_ind in [62690]:
            output_dir_temp = directory+'/splt_and_ext' + "/" + '2022-11-12-15-57-44-13'

            with open(output_dir_temp + '/expected_num_change_cross_SLF_in_orig_dict_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                expected_num_change_cross_SLF_in_orig_dict = pickle.load(input)
            #print (expected_num_change_cross_SLF_in_orig_dict)


        sum_expected_num_change_orig_rnase_dict = {}
        sum_expected_num_change_mut_rnase_dict = {}
        sum_expected_num_change_cross_SLF_in_orig_dict = {}
        sum_expected_num_change_cross_SLF_in_mut_dict = {}

        for i, expected_dict in expected_num_change_orig_rnase_dict.items():
            for iter_ind, num in expected_dict.items():
                if not np.isnan(num):
                    if iter_ind not in sum_expected_num_change_orig_rnase_dict:
                        sum_expected_num_change_orig_rnase_dict[iter_ind] = 0
                    sum_expected_num_change_orig_rnase_dict[iter_ind] += num

        for i, expected_dict in expected_num_change_mut_rnase_dict.items():
            for iter_ind, num in expected_dict.items():
                if not np.isnan(num):
                    if iter_ind not in sum_expected_num_change_mut_rnase_dict:
                        sum_expected_num_change_mut_rnase_dict[iter_ind] = 0
                    sum_expected_num_change_mut_rnase_dict[iter_ind] += num

        for i, expected_dict in expected_num_change_cross_SLF_in_orig_dict.items():
            for iter_ind, num in expected_dict.items():
                if not np.isnan(num):
                    if iter_ind not in sum_expected_num_change_cross_SLF_in_orig_dict:
                        sum_expected_num_change_cross_SLF_in_orig_dict[iter_ind] = 0
                    sum_expected_num_change_cross_SLF_in_orig_dict[iter_ind] += num

        for i, expected_dict in expected_num_change_cross_SLF_in_mut_dict.items():
            for iter_ind, num in expected_dict.items():
                if not np.isnan(num):
                    if iter_ind not in sum_expected_num_change_cross_SLF_in_mut_dict:
                        sum_expected_num_change_cross_SLF_in_mut_dict[iter_ind] = 0
                    sum_expected_num_change_cross_SLF_in_mut_dict[iter_ind] += num


        with open(output_dir + '/ext_group_count_arr_ext_iter_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            ext_group_count_arr = pickle.load(input)

        with open(output_dir + '/ext_append_group_count_arr_ext_iter_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            ext_append_group_count_arr = pickle.load(input)

        with open(output_dir + '/iters_values_ext_iter_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            iters_values = pickle.load(input)


        with open(output_dir + '/fitness_avg_dict_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(
                    mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
            fitness_avg_dict = pickle.load(input)
        #print (fitness_avg_dict)

        with open(output_dir + '/tot_fitness_hap_orig_rnase_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(
                    mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
            tot_fitness_hap_orig_rnase = pickle.load(input)

        with open(output_dir + '/tot_fitness_hap_mut_rnase_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(
                    mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
            tot_fitness_hap_mut_rnase = pickle.load(input)

        with open(output_dir + '/tot_fitness_hap_ext_gro_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(
                    mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
            tot_fitness_hap_ext_gro = pickle.load(input)

        with open(output_dir + '/tot_num_hap_ext_gro_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(
                    mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
            tot_num_hap_ext_gro = pickle.load(input)

        sum_tot_num_hap_ext_gro = {}
        for i, num_hap_ext_gro in tot_num_hap_ext_gro.items():
            for iter_ind, num in num_hap_ext_gro.items():
                if not np.isnan(num):
                    if iter_ind not in sum_tot_num_hap_ext_gro:
                        sum_tot_num_hap_ext_gro[iter_ind] = 0
                    sum_tot_num_hap_ext_gro[iter_ind] += num

        with open(output_dir + '/expected_num_change_mut_rnase_dict_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            expected_num_change_mut_rnase_dict = pickle.load(input)

        with open(output_dir + '/expected_num_change_ext_gro_dict_' + str(
                iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
            extinct_group) + '_' + str(
            min_duration * 10) + '_.pkl', 'rb') as input:
            expected_num_change_ext_gro_dict = pickle.load(input)

        sum_expected_num_change_mut_rnase_dict = {}
        for i, expected_dict in expected_num_change_mut_rnase_dict.items():
            for iter_ind, num in expected_dict.items():
                if not np.isnan(num):
                    if iter_ind not in sum_expected_num_change_mut_rnase_dict:
                        sum_expected_num_change_mut_rnase_dict[iter_ind] = 0
                    sum_expected_num_change_mut_rnase_dict[iter_ind] += num

        sum_expected_num_change_ext_gro_dict = {}
        for i, expected_dict in expected_num_change_ext_gro_dict.items():
            for iter_ind, num in expected_dict.items():
                if not np.isnan(num):
                    if iter_ind not in sum_expected_num_change_ext_gro_dict:
                        sum_expected_num_change_ext_gro_dict[iter_ind] = 0
                    sum_expected_num_change_ext_gro_dict[iter_ind] += num

        sum_expected_num_change_cross_SLF_in_orig_dict = {}
        for i, expected_dict in expected_num_change_cross_SLF_in_orig_dict.items():
            if len(list(expected_dict.values())) > 3:
                for iter_ind, num in expected_dict.items():
                    if not np.isnan(num):
                        if iter_ind not in sum_expected_num_change_cross_SLF_in_orig_dict:
                            sum_expected_num_change_cross_SLF_in_orig_dict[iter_ind] = 0
                        sum_expected_num_change_cross_SLF_in_orig_dict[iter_ind] += num



    box_1_Panel_1_Data = [
        sum_tot_num_hap_orig_rnase, \
        sum_tot_num_hap_mut_rnase, \
        sum_tot_num_hap_cross_orig_rnase, \
        sum_tot_num_hap_cross_mut_rnase, \
        ext_group_count_arr, \
        ext_append_group_count_arr
        ]

    box_1_Panel_2_Data = [
        tot_fitness_hap_ext_gro, \
        tot_fitness_hap_orig_rnase, \
        tot_fitness_hap_mut_rnase, \
        tot_fitness_hap_cross_orig_rnase, \
        tot_fitness_hap_cross_mut_rnase
        ]

    box_1_Panel_3_Data = [
        sum_expected_num_change_orig_rnase_dict, \
        sum_expected_num_change_mut_rnase_dict, \
        sum_expected_num_change_cross_SLF_in_orig_dict, \
        sum_expected_num_change_cross_SLF_in_mut_dict, \
        sum_expected_num_change_ext_gro_dict
        ]

    return [box_1_Panel_1_Data, box_1_Panel_2_Data, box_1_Panel_3_Data, fitness_avg_dict, iters_values]




#
#
#
#############
def fert_Mut_Class_SI(input_Var): # Box plot

    fig = plt.figure(figsize=(7.0,11.3))
    plt.subplots_adjust(top=0.970, bottom=0.004, left=0.083, right=0.990, hspace=25.25, wspace=25.5)
    fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 10, 9, 7.5, 8

    fig_Grid_Size = (200,53)
    height_Row, height_Col = 16, 24
    small_gap, big_gap, small_gap_Col, extra_ini_gap = 1, 9, 5, 8
    subplot_Index = [0, 2, 4, 1, 3, 5, 6, 8, 10, 7, 9, 11]
    fig_Title = ['a', 'a', 'b', 'b', 'c', 'c', 'a', 'd', 'b', 'b', 'c', 'c']
    fig_Title = ['a', 'b', 'c']
    alpha_Color = 0.25

    color_b, color_r = [0/2**8,158/2**8,231/2**8], [175/2**8,45/2**8,47/2**8]
    lw = 0.5; mW = 1.5; mS = 6.5

    #Neutral: 80590
    #Extinction – cross in SLFmut: 90920
    #Extinction + split: 62690

    splt_iter = 80590
    box_1_Panel_1_Data, box_1_Panel_2_Data, box_1_Panel_3_Data, fitness_avg_dict, iters_values = data_To_Plot(splt_iter)
    x_limit = [80240, 80690]
    #print (box_1_Panel_2_Data)

    for index_fig, box_Data, fig_range in zip(subplot_Index[:3], [box_1_Panel_1_Data, box_1_Panel_2_Data, box_1_Panel_3_Data], range(3)):
        ax = plt.subplot2grid(fig_Grid_Size, ((height_Row+small_gap)*(index_fig//2)+extra_ini_gap, (height_Col+small_gap_Col)*(index_fig%2)), \
                rowspan=height_Row-1, colspan=fig_Grid_Size[1]-0)
        ax.spines.right.set_visible(False)
        ax.spines.top.set_visible(False)
        #if fig_range == 0:  ax.set_title(fig_Title[fig_range], loc='left', fontweight='bold')

        if fig_range in [0, 2]:
            if fig_range == 0:
                line1, = ax.plot(iters_values[:33], (box_Data[4]+box_Data[5])[:33],
                    color=[0.5, 0.5, 0.5], marker='o', markeredgewidth=mW, markersize=mS-3, linewidth=lw, label='extinct group (+ appendix)')
            if fig_range == 2:
                line1, = ax.plot(list(box_Data[4].keys()), list(box_Data[4].values()),
                    color=[0.5, 0.5, 0.5], marker='o', markeredgewidth=mW, markersize=mS-3, linewidth=lw, label='extinct group (+ appendix)')

            if fig_range == 0:
                p_mut4, = ax.plot([splt_iter-20, splt_iter-20], [-10, 160], color=color_r, linestyle='dashed', label='split', linewidth=lw)
            if fig_range == 2:
                p_mut4, = ax.plot([splt_iter-20, splt_iter-20], [-150, 225], color=color_r, linestyle='dashed', label='split', linewidth=lw)

            # line2, = ax1.plot(iters_values, group_size + append_group_size,
            #       color='k', marker='*', label='RNase group (+ appendix)')



            p_num_rnase_orig, = ax.plot(list(box_Data[0].keys()), \
                   list(box_Data[0].values()), \
                markerfacecolor=color_b, markeredgecolor=color_b, marker="_",markeredgewidth=mW, markersize=mS, linewidth=lw, color = [0.5,0.5,0.5],
                label='orig. RNase')


            p_num_rnase_mut, = ax.plot(list(box_Data[1].keys()), \
                   list(box_Data[1].values()), \
                markerfacecolor=color_r, markeredgecolor=color_r,  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, color = [0.5,0.5,0.5],
                label='mut. RNase')


            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2].keys()), \
                   list(box_Data[2].values()), \
                markerfacecolor='r', markeredgecolor='r',  marker='o', markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'b',
                label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2].keys()), \
                   list(box_Data[2].values()), \
                markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw, linestyle='none',
                label='orig. RNase + cross SLF mut.')


            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3].keys()), \
                      list(box_Data[3].values()), \
                markerfacecolor='b', markeredgecolor='b',  marker='o', markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'r',
                label='mut. RNase + cross SLF mut.')# haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3].keys()), \
                      list(box_Data[3].values()), \
                markerfacecolor='r', markeredgecolor='r',  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, linestyle='none',
                label='mut. RNase + cross SLF mut.')

            if fig_range == 2:
                ax.fill_between(x_limit, -65, 0, color='black', alpha=0.15, edgecolor="w")

        else:
            divide_by = 1000/2
            p_fitness_avg, = ax.plot(list(fitness_avg_dict.keys()), np.array(list(fitness_avg_dict.values()))/(divide_by), \
                                    color='k', linestyle='dashed', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                    label='avg fitness')
            p_mut4, = ax.plot([splt_iter-20, splt_iter-20], [0.5, 0.9], color=color_r, linestyle='dashed', label='split', linewidth=lw)

            fitness_avg_dict_to_plot ={}
            for index in range(4):
                if len(list(box_Data[0][index].keys()))>3:
                    p_num_rnase_orig, = ax.plot(list(box_Data[0][index].keys()), \
                           np.array(list(box_Data[0][index].values()))/divide_by, \
                        color = [0.5,0.5,0.5], marker='o', markeredgewidth=mW, markersize=mS-3, linewidth=lw, label='ext gro')

                if len(list(box_Data[1][index].keys()))>3:
                    p_num_rnase_orig, = ax.plot(list(box_Data[1][index].keys()), \
                           np.array(list(box_Data[1][index].values()))/divide_by, \
                        markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw, color = [0.5,0.5,0.5],
                        label='orig. RNase')

                #if len(list(box_Data[2][index].keys()))>3:
                #    p_num_rnase_mut, = ax.plot(list(box_Data[2][index].keys()), \
                #           np.array(list(box_Data[2][index].values()))/divide_by, \
                #        markerfacecolor=color_r, markeredgecolor=color_r,  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, color = [0.5,0.5,0.5],
                #        label='mut. RNase')
                #    print (list(box_Data[2][index].keys()), list(box_Data[2][index].values()),  '------------------')

                if len(list(box_Data[2][index].keys()))>3:

                    for gen_key, gen_value in zip(list(box_Data[2][index].keys()), np.array(list(box_Data[2][index].values()))/divide_by):

                        if gen_key not in fitness_avg_dict_to_plot:
                                fitness_avg_dict_to_plot[gen_key] = [gen_value]
                        else:
                            fitness_avg_dict_to_plot[gen_key].append(gen_value)

                if len(list(box_Data[3][index].keys()))>3:
                    p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[3][index].keys()), \
                           np.array(list(box_Data[3][index].values()))/divide_by, \
                        markerfacecolor='r', markeredgecolor='r',  marker='o', markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'b',
                        label='orig. RNase + cross SLF mut.')

                    p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[3][index].keys()), \
                           np.array(list(box_Data[3][index].values()))/divide_by, \
                        markerfacecolor='b', markeredgecolor='b', marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw, linestyle='none',
                        label='orig. RNase + cross SLF mut.')

                if len(list(box_Data[4][index].keys()))>3:
                    print ('\n', list(box_Data[4][index].keys()), np.array(list(box_Data[4][index].values()))/divide_by)

                    for gen_key, gen_value in zip(list(box_Data[4][index].keys()), np.array(list(box_Data[4][index].values()))/divide_by):

                        if gen_key not in fitness_avg_dict_to_plot:
                                fitness_avg_dict_to_plot[gen_key] = [gen_value]
                        else:
                            fitness_avg_dict_to_plot[gen_key].append(gen_value)

                    '''
                    p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                              np.array(list(box_Data[4][index].values()))/divide_by, \
                        markerfacecolor=[0/2**8,158/2**8,231/2**8], markeredgecolor='None',  marker='o', alpha=alpha_Color, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'r',
                        label='mut. RNase + cross SLF mut.')# haplotype that has a SLF cross mutation

                    p_num_rnase_mut_slf_cross_line, = ax.plot(list(box_Data[4][index].keys()), \
                              np.array(list(box_Data[4][index].values()))/divide_by, \
                        markerfacecolor='b', markeredgecolor='None',  marker='None', alpha=1, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'r',
                        label='mut. RNase + cross SLF mut.')# haplotype that has a SLF cross mutation

                    p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                              np.array(list(box_Data[4][index].values()))/divide_by, \
                        markerfacecolor='r', markeredgecolor='r',  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, linestyle='none',
                        label='mut. RNase + cross SLF mut.')
                    '''

            for key, value in zip(list(fitness_avg_dict_to_plot.keys()), list(fitness_avg_dict_to_plot.values())):
                fitness_avg_dict_to_plot[key] = np.nanmean(value)

            p_num_rnase_mut, = ax.plot(list(fitness_avg_dict_to_plot.keys()), \
                   np.array(list(fitness_avg_dict_to_plot.values())), \
                markerfacecolor=color_r, markeredgecolor=color_r,  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, color = [0.5,0.5,0.5],
                label='mut. RNase')




        #if fig_range == 2:
        #    ax.set_xlabel('Generation', fontsize=fontsizeX, labelpad=0)

        if fig_range == 0:
            ax.set_ylabel(r'$X_{i}$', fontsize=fontsizeY, labelpad=9.0)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([],  minor = False)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([80350+i*10 for i in range(-10,34)],  minor = True)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([0, 50, 100], minor = False)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(0,135,25/2), minor = True)
            ax.set_ylim(-9,142)

        if fig_range == 1:
            ax.set_ylabel(r'$f_{i}$', fontsize=fontsizeY, labelpad=8)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([],  minor = False)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([80350+i*10 for i in range(-10,34)],  minor = True)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(0.58,0.90,0.02), minor = True)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([0.60, 0.7, 0.8, 0.90], minor = False)
            ax.set_ylim(0.57,0.90)

        if fig_range == 2:
            ax.set_ylabel(r'$\tilde{X_{i}}$', fontsize=fontsizeY, labelpad=4.75)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([80350+i*10 for i in range(-10,34)],  minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([80350+i*50 for i in range(-2,7)], [r'$t_{0}$'+'{}'.format(i*50) if i < 0 else r'$t_{0}$' if i == 0 else r'$t_{0}$+'+'{}'.format(i*50) for i in range(-2,7)], minor = False)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([-50, 0, 50, 100, 150], minor = False)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(-50,150,25/2), minor = True)
            ax.set_ylim(-50,155)

        ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax.set_xlim(x_limit)



    lw = 0.5; mW = 1.5; mS = 7

    splt_iter = 65820
    box_2_Panel_1_Data, box_2_Panel_2_Data, box_2_Panel_3_Data, fitness_avg_dict, iters_values = data_To_Plot(splt_iter)
    x_limit = [65620, 65920] #[33470, 33730] #[90660, 91015]

    for index_fig, box_Data, fig_range in zip(subplot_Index[6:9], [box_2_Panel_1_Data, box_2_Panel_2_Data, box_2_Panel_3_Data], range(3)):
        ax = plt.subplot2grid(fig_Grid_Size, ((height_Row+small_gap)*(index_fig//2)+big_gap+extra_ini_gap+9, (height_Col+small_gap_Col)*(index_fig%2)), \
                rowspan=height_Row-1, colspan=fig_Grid_Size[1]-0)
        ax.spines.right.set_visible(False)
        ax.spines.top.set_visible(False)
        #if fig_range == 0:  ax.set_title(fig_Title[fig_range+1], loc='left', fontweight='bold')


        if fig_range in [0, 2]:
            if fig_range == 0:
                line1, = ax.plot(iters_values[:-10], box_Data[4][:-10]+box_Data[5][:-10],
                    color=[0.5, 0.5, 0.5], marker='o', markeredgewidth=mW, markersize=mS-3, linewidth=lw, label='extinct group (+ appendix)')
            if fig_range == 2:
                line1, = ax.plot(list(box_Data[4].keys()), list(box_Data[4].values()),
                    color=[0.5, 0.5, 0.5], marker='o', markeredgewidth=mW, markersize=mS-3, linewidth=lw, label='extinct group (+ appendix)')

            if fig_range == 0:
                p_mut4, = ax.plot([splt_iter-10, splt_iter-10], [-10, 145], color=color_r, linestyle='dashed', label='split', linewidth=lw)
            if fig_range == 2:
                p_mut4, = ax.plot([splt_iter-10, splt_iter-10], [-150, 225], color=color_r, linestyle='dashed', label='split', linewidth=lw)

            # line2, = ax1.plot(iters_values, group_size + append_group_size,
            #       color='k', marker='*', label='RNase group (+ appendix)')


            p_num_rnase_orig, = ax.plot(list(box_Data[0].keys()), \
                   list(box_Data[0].values()), \
                markerfacecolor=color_b, markeredgecolor=color_b, marker="_",markeredgewidth=mW, markersize=mS, linewidth=lw, color = [0.5,0.5,0.5],
                label='orig. RNase')


            p_num_rnase_mut, = ax.plot(list(box_Data[1].keys()), \
                   list(box_Data[1].values()), \
                markerfacecolor=color_r, markeredgecolor=color_r,  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, color = [0.5,0.5,0.5],
                label='mut. RNase')


            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2].keys()), \
                   list(box_Data[2].values()), \
                markerfacecolor=color_r, markeredgecolor=color_r,  marker='o', alpha=alpha_Color, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'b',
                label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2].keys()), \
                   list(box_Data[2].values()), \
                markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw, linestyle='none',
                label='orig. RNase + cross SLF mut.')

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3].keys()), \
                      list(box_Data[3].values()), \
                markerfacecolor=color_b, markeredgecolor='None',  marker='o', alpha=alpha_Color, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'r',
                label='mut. RNase + cross SLF mut.')# haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross_line, = ax.plot(list(box_Data[3].keys()), \
                      list(box_Data[3].values()), \
                markerfacecolor=color_b, markeredgecolor='None',  marker='None', alpha=alpha_Color, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'r',
                label='mut. RNase + cross SLF mut.')# haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3].keys()), \
                      list(box_Data[3].values()), \
                markerfacecolor=color_r, markeredgecolor=color_r,  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, linestyle='-', color=color_r,
                label='mut. RNase + cross SLF mut.')

            if fig_range == 2:
                ax.fill_between(x_limit, -70, 0, color='black', alpha=0.15, edgecolor="w")

        else:
            divide_by = 1000/2
            p_fitness_avg, = ax.plot(list(fitness_avg_dict.keys())[:-2], np.array(list(fitness_avg_dict.values()))[:-2]/divide_by, \
                                    color='k', linestyle='dashed', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                    label='avg fitness')

            p_mut4, = ax.plot([splt_iter-10, splt_iter-10], [0.6, 1.0], color=color_r, linestyle='dashed', label='split', linewidth=lw)


            fitness_avg_dict_to_plot = {} # because there are twp different haplotypes

            for index in range(2):
                if len(list(box_Data[0][index].keys()))>1:
                    p_num_rnase_orig, = ax.plot(list(box_Data[0][index].keys()), \
                           np.array(list(box_Data[0][index].values()))/divide_by, \
                        color = [0.5,0.5,0.5], marker='o', markeredgewidth=mW, markersize=mS-3, linewidth=lw, label='ext gro')

                if len(list(box_Data[1][index].keys()))>0:
                    p_num_rnase_orig, = ax.plot(list(box_Data[1][index].keys()), \
                           np.array(list(box_Data[1][index].values()))/divide_by, \
                        markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw, color = [0.5,0.5,0.5],
                        label='orig. RNase')
                #print (list(box_Data[2][index].keys()), list(box_Data[2][index].values()), index)

                if len(list(box_Data[2][index].keys()))>0:
                    p_num_rnase_mut, = ax.plot(list(box_Data[2][index].keys()), \
                           np.array(list(box_Data[2][index].values()))/divide_by, \
                        markerfacecolor=color_r, markeredgecolor=color_r,  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, color = [0.5,0.5,0.5],
                        label='mut. RNase')

                if len(list(box_Data[3][index].keys())) > 3:
                    p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[3][index].keys()), \
                           np.array(list(box_Data[3][index].values()))/divide_by, \
                        markerfacecolor='r', markeredgecolor='r',  marker='o', alpha=alpha_Color, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'b',
                        label='orig. RNase + cross SLF mut.')

                    p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[3][index].keys()), \
                           np.array(list(box_Data[3][index].values()))/divide_by, \
                        markerfacecolor='b', markeredgecolor='b', marker="_", alpha=alpha_Color, markeredgewidth=mW, markersize=mS, linewidth=lw, linestyle='None',
                        label='orig. RNase + cross SLF mut.')

                if len(list(box_Data[4][index].keys()))>3:
                    print ('\n', list(box_Data[4][index].keys()), np.array(list(box_Data[4][index].values()))/divide_by)

                    for gen_key, gen_value in zip(list(box_Data[4][index].keys()), np.array(list(box_Data[4][index].values()))/divide_by):

                        if gen_key not in fitness_avg_dict_to_plot:
                                fitness_avg_dict_to_plot[gen_key] = [gen_value]
                        else:
                            fitness_avg_dict_to_plot[gen_key].append(gen_value)

                    '''
                    p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                              np.array(list(box_Data[4][index].values()))/divide_by, \
                        markerfacecolor=[0/2**8,158/2**8,231/2**8], markeredgecolor='None',  marker='o', alpha=alpha_Color, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'r',
                        label='mut. RNase + cross SLF mut.')# haplotype that has a SLF cross mutation

                    p_num_rnase_mut_slf_cross_line, = ax.plot(list(box_Data[4][index].keys()), \
                              np.array(list(box_Data[4][index].values()))/divide_by, \
                        markerfacecolor='b', markeredgecolor='None',  marker='None', alpha=1, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'r',
                        label='mut. RNase + cross SLF mut.')# haplotype that has a SLF cross mutation

                    p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                              np.array(list(box_Data[4][index].values()))/divide_by, \
                        markerfacecolor='r', markeredgecolor='r',  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, linestyle='none',
                        label='mut. RNase + cross SLF mut.')
                    '''

            for key, value in zip(list(fitness_avg_dict_to_plot.keys()), list(fitness_avg_dict_to_plot.values())):
                fitness_avg_dict_to_plot[key] = np.nanmean(value)

            p_num_rnase_mut_slf_cross, = ax.plot(list(fitness_avg_dict_to_plot.keys()), \
                      np.array(list(fitness_avg_dict_to_plot.values())), \
                markerfacecolor=color_b, markeredgecolor='None',  marker='o', alpha=alpha_Color, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'r',
                label='mut. RNase + cross SLF mut.')# haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross_line, = ax.plot(list(fitness_avg_dict_to_plot.keys()), \
                      np.array(list(fitness_avg_dict_to_plot.values())), \
                markerfacecolor='b', markeredgecolor='None',  marker='None', alpha=1, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'r',
                label='mut. RNase + cross SLF mut.')# haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross, = ax.plot(list(fitness_avg_dict_to_plot.keys()), \
                      np.array(list(fitness_avg_dict_to_plot.values())), \
                markerfacecolor=color_r, markeredgecolor=color_r,  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, linestyle='-', color=color_r,
                label='mut. RNase + cross SLF mut.')

            print (fitness_avg_dict_to_plot)



        #if fig_range == 2:
        #    ax.set_xlabel('Generation', fontsize=fontsizeX, labelpad=0)

        if fig_range == 0:
            ax.set_ylabel(r'$X_{i}$', fontsize=fontsizeY, labelpad=9.0)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([],  minor = False)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([65620+i*10 for i in range(26)], minor = True)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(0,180,10), minor = True)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([0, 50, 100, 150], minor = False)
            ax.set_ylim(-15,180)

        if fig_range == 1:
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([],  minor = False)
            ax.set_ylabel(r'$f_{i}$', fontsize=fontsizeY, labelpad=8)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([65620+i*10 for i in range(26)], minor = True)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(0.62,1.0,0.02), minor = True)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([0.7, 0.8, 0.90, 1.0], minor = False)
            ax.set_ylim(0.62,1.02)

        if fig_range == 2:
            ax.set_ylabel(r'$\tilde{X_{i}}$', fontsize=fontsizeY, labelpad=5.0)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([65620+i*10 for i in range(26)], minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([65620+i*50+10 for i in range(6)], [r'$t_{0}$'+'{}'.format(i*50) if i < 0 else r'$t_{0}$' if i == 0 else r'$t_{0}$+'+'{}'.format(i*50) for i in range(-2,4)], minor = False)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([-50, 0, 50, 100, 150], minor = False)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(-50,151,25/2), minor = True)
            ax.set_ylim(-30,150)

        ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax.set_xlim(x_limit)




    splt_iter = 62690
    box_3_Panel_1_Data, box_3_Panel_2_Data, box_3_Panel_3_Data, fitness_avg_dict, iters_values = data_To_Plot(splt_iter)
    x_limit = [62452, 62788]
    subplot_Index = [12, 14, 16]
    for index_fig, box_Data, fig_range in zip(subplot_Index, [box_3_Panel_1_Data, box_3_Panel_2_Data, box_3_Panel_3_Data], range(3)):
        ax = plt.subplot2grid(fig_Grid_Size, ((height_Row+small_gap)*(index_fig//2)+big_gap+extra_ini_gap+26, 0), \
                rowspan=height_Row-1, colspan=fig_Grid_Size[1]-0)
        ax.spines.right.set_visible(False)
        ax.spines.top.set_visible(False)
        #if fig_range == 0:  ax.set_title(fig_Title[fig_range+2], loc='left', fontweight='bold')

        if fig_range in [0, 2]:
            if fig_range == 0:
                line1, = ax.plot(iters_values[:-10], box_Data[4][:-10]+box_Data[5][:-10],
                    color=[0.5, 0.5, 0.5], marker='o', markeredgewidth=mW, markersize=mS-3, linewidth=lw, label='extinct group (+ appendix)')
            if fig_range == 2:
                line1, = ax.plot(list(box_Data[4].keys()), list(box_Data[4].values()),
                    color=[0.5, 0.5, 0.5], marker='o', markeredgewidth=mW, markersize=mS-3, linewidth=lw, label='extinct group (+ appendix)')

            if fig_range == 0:
                p_mut4, = ax.plot([splt_iter-10, splt_iter-10], [-10, 160], color=color_r, linestyle='dashed', label='split', linewidth=lw)
            if fig_range == 2:
                p_mut4, = ax.plot([splt_iter-10, splt_iter-10], [-150, 225], color=color_r, linestyle='dashed', label='split', linewidth=lw)

            # line2, = ax1.plot(iters_values, group_size + append_group_size,
            #       color='k', marker='*', label='RNase group (+ appendix)')



            p_num_rnase_orig, = ax.plot(list(box_Data[0].keys())[:22], \
                   list(box_Data[0].values())[:22], \
                markerfacecolor=color_b, markeredgecolor=color_b, marker="_",markeredgewidth=mW, markersize=mS, linewidth=lw, color = [0.5,0.5,0.5],
                label='orig. RNase')

            if fig_range == 10:
                print (list(box_Data[0].keys()))
                print (list(box_Data[0].values()))

            p_num_rnase_mut, = ax.plot(list(box_Data[1].keys()), \
                   list(box_Data[1].values()), \
                markerfacecolor=color_r, markeredgecolor=color_r,  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, color = [0.5,0.5,0.5],
                label='mut. RNase')



            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2].keys()), \
                   list(box_Data[2].values()), \
                markerfacecolor=color_r, markeredgecolor='none',  marker='o', alpha=alpha_Color, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'b',
                label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross_line, = ax.plot(list(box_Data[2].keys()), \
                   list(box_Data[2].values()), \
                markerfacecolor='r', markeredgecolor='none',  marker='None', alpha=1, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'b',
                label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2].keys()), \
                   list(box_Data[2].values()), \
                markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw, linestyle='-', color=color_b,
                label='orig. RNase + cross SLF mut.')




            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3].keys()), \
                      list(box_Data[3].values()), \
                markerfacecolor=color_b, markeredgecolor='none',  marker='o', alpha=alpha_Color, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'r',
                label='mut. RNase + cross SLF mut.')# haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross_line, = ax.plot(list(box_Data[3].keys()), \
                      list(box_Data[3].values()), \
                markerfacecolor=color_b, markeredgecolor='none',  marker='None', alpha=1, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'r',
                label='mut. RNase + cross SLF mut.')# haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3].keys()), \
                      list(box_Data[3].values()), \
                markerfacecolor=color_r, markeredgecolor=color_r,  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, linestyle='-', color=color_r,
                label='mut. RNase + cross SLF mut.')

            if fig_range == 2:
                ax.fill_between(x_limit, -65, 0, color='black', alpha=0.15, edgecolor="w")

        else:
            divide_by = 1000/2
            p_fitness_avg, = ax.plot(list(fitness_avg_dict.keys()), np.array(list(fitness_avg_dict.values()))/divide_by, \
                                    color='k', linestyle='dashed', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                    label='avg fitness')

            p_mut4, = ax.plot([splt_iter-10, splt_iter-10], [0.5, 1.0], color=color_r, linestyle='dashed', label='split', linewidth=lw)

            for index in range(2):
                if len(list(box_Data[0][index].keys()))>3:
                    p_num_rnase_orig, = ax.plot(list(box_Data[0][index].keys()), \
                           np.array(list(box_Data[0][index].values()))/divide_by, \
                        color = [0.5,0.5,0.5], marker='o', markeredgewidth=mW, markersize=mS-3, linewidth=lw, label='ext gro')

                if len(list(box_Data[1][index].keys()))>3:
                    p_num_rnase_orig, = ax.plot(list(box_Data[1][index].keys())[:22], \
                           np.array(list(box_Data[1][index].values())[:22])/divide_by, \
                        markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw, color = [0.5,0.5,0.5],
                        label='orig. RNase')

                if len(list(box_Data[2][index].keys()))>3:
                    p_num_rnase_mut, = ax.plot(list(box_Data[2][index].keys()), \
                           np.array(list(box_Data[2][index].values()))/divide_by, \
                        markerfacecolor=color_r, markeredgecolor=color_r,  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, color = [0.5,0.5,0.5],
                        label='mut. RNase')

            for index in range(15):
                data_curr = box_Data[3][index]
                if len(data_curr)>3:
                    if 62680 in data_curr.keys():
                        data_curr[62670] = data_curr[62680]
                        to_sort = np.sort(list(data_curr.keys()))
                        data_curr = {iter: data_curr[iter] for iter in to_sort}


                    p_num_rnase_orig_slf_cross, = ax.plot(list(data_curr.keys()), \
                           np.array(list(data_curr.values()))/divide_by, \
                        markerfacecolor=color_r, markeredgecolor='none',  marker='o', alpha=alpha_Color, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'b',
                        label='orig. RNase + cross SLF mut.')

                    p_num_rnase_orig_slf_cross_line, = ax.plot(list(data_curr.keys()), \
                           np.array(list(data_curr.values()))/divide_by, \
                        markerfacecolor='r', markeredgecolor='none',  marker='None', alpha=1, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'b',
                        label='orig. RNase + cross SLF mut.')

                    p_num_rnase_orig_slf_cross, = ax.plot(list(data_curr.keys()), \
                           np.array(list(data_curr.values()))/divide_by, \
                        markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw, linestyle='-', color=color_b,
                        label='orig. RNase + cross SLF mut.')


                if len(list(box_Data[4][index].keys()))>3:
                    p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                              np.array(list(box_Data[4][index].values()))/(divide_by), \
                        markerfacecolor=color_b, markeredgecolor='none',  marker='o', alpha=alpha_Color, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'r',
                        label='mut. RNase + cross SLF mut.')# haplotype that has a SLF cross mutation

                    p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                              np.array(list(box_Data[4][index].values()))/(divide_by), \
                        markerfacecolor=color_b, markeredgecolor='none',  marker='None', alpha=1, markeredgewidth=mW, markersize=mS, linewidth=lw, color = 'r',
                        label='mut. RNase + cross SLF mut.')# haplotype that has a SLF cross mutation

                    p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                              np.array(list(box_Data[4][index].values()))/(divide_by), \
                        markerfacecolor=color_r, markeredgecolor=color_r,  marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw, linestyle='-', color=color_r,
                        label='mut. RNase + cross SLF mut.')





        if fig_range == 2:
            ax.set_xlabel('Generation', fontsize=fontsizeX)

        if fig_range == 0:
            ax.set_ylabel(r'$X_{i}$', fontsize=fontsizeY, labelpad=9)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([62560+i*10 for i in range(-10,23)], minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([], minor = False)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([0, 50, 100, 150], minor = False)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(0,160,25/2), minor = True)
            ax.set_ylim(-12,165)

        if fig_range == 1:
            ax.set_ylabel(r'$f_{i}$', fontsize=fontsizeY, labelpad=9.5)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([62560+i*10 for i in range(-10,23)], minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([], minor = False)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(0.64,1.0,0.02), minor = True)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([0.7, 0.8, 0.9, 1.0], minor = False)
            ax.set_ylim(0.64, 1.0)

        if fig_range == 2:
            ax.set_ylabel(r'$\tilde{X_{i}}$', fontsize=fontsizeY, labelpad=6)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([62560+i*10 for i in range(-10,23)], minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([62560+i*50 for i in range(-2,5)], [r'$t_{0}$'+'{}'.format(i*50) if i < 0 else r'$t_{0}$' if i == 0 else r'$t_{0}$+'+'{}'.format(i*50) for i in range(-2,5)], minor = False)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([-50, 0, 50, 100, 150], minor = False)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(-20,151,10), minor = True)
            ax.set_ylim(-29,155)

        ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax.set_xlim(x_limit)



    plt.savefig('./figures/Fig_7_diploid_based_average.pdf', transparent=True)
    #plt.show()
    plt.close()


    return 'done'

input_Var = 0
print (fert_Mut_Class_SI(input_Var))








print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
