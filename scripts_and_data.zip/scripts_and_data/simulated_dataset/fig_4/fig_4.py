#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys
import collections, pickle
from datetime import datetime
#from numba import jit
import pickle
from scipy.optimize import curve_fit
import matplotlib.ticker as mtick
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)


E = -6

x_lim_min = 4
x_lim_max = 13.5
directory = './data_fig_4'


cum_t_n_gro_dict = pickle.load(open(directory + '/cum_t_n_gro_dict.pkl', 'rb'))
n_gro_before_splt_dict = pickle.load(open(directory + '/n_gro_before_splt_dict.pkl', 'rb'))
n_gro_before_ext_dict = pickle.load(open(directory + '/n_gro_before_ext_dict.pkl', 'rb'))

n_gro_before_ext_all_files_dict = {}
n_gro_before_splt_all_files_dict = {}
for n_gro in range(3,30):
    n_gro_before_ext_all_files_dict[n_gro] = 0
    n_gro_before_splt_all_files_dict[n_gro] = 0

for vals in n_gro_before_ext_dict.values():
    for n_gro, num in vals.items():
        n_gro_before_ext_all_files_dict[n_gro] += num

for vals in n_gro_before_splt_dict.values():
    for n_gro, num in vals.items():
        n_gro_before_splt_all_files_dict[n_gro] += num

p_ext_given_k_gro = {}
p_splt_given_k_gro = {}

for n_gro in range(3,14):
    if cum_t_n_gro_dict[n_gro] == 0:
        p_ext_given_k_gro[n_gro] = np.nan
        p_splt_given_k_gro[n_gro] = np.nan

    else:
        p_ext_given_k_gro[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
            cum_t_n_gro_dict[n_gro]
        p_splt_given_k_gro[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
            cum_t_n_gro_dict[n_gro]

p_gro_before_ext_all_files_dict = {}
p_gro_before_splt_all_files_dict = {}
for n_gro in range(3,14):
    p_gro_before_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
        np.sum(list(n_gro_before_ext_all_files_dict.values()))

    p_gro_before_splt_all_files_dict[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
        np.sum(list(n_gro_before_splt_all_files_dict.values()))





fig = plt.figure(figsize=(8,2.5))
plt.subplots_adjust(top=0.913, bottom=0.144, left=0.057, right=0.988, hspace=0.35, wspace=0.28)
fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 9, 9, 7.5, 8


Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
alpha_Color = 0.25
lw = 0.5; mW = 1.5; mS = 6
color1, color2, color3 = 'g', 'b', 'r'




data_1_key, data_1_value = np.array(list(cum_t_n_gro_dict.keys())), list(cum_t_n_gro_dict.values())/np.sum(list(cum_t_n_gro_dict.values()))
width = 0.3
data_2a_key, data_2a_value = np.arange(3,14)-width/2, list(p_gro_before_ext_all_files_dict.values())
data_2b_key, data_2b_value = np.arange(3,14)+width/2, list(p_gro_before_splt_all_files_dict.values())
data_3a_key, data_3a_value = np.array(list(p_ext_given_k_gro.keys())) - width/2, np.array(list(p_ext_given_k_gro.values()))*1000
data_3b_key, data_3b_value = np.array(list(p_splt_given_k_gro.keys())) + width/2, np.array(list(p_splt_given_k_gro.values()))*1000



width1=0.4
binSize = 28

ax1 = plt.subplot(1, 3, 1)
ax1.spines.right.set_visible(False)
ax1.spines.top.set_visible(False)
ax1.bar(data_1_key, data_1_value, color = 'k', width = width1)
ax1.tick_params(axis = 'y', which = 'minor', labelsize = 0)
ax1.set_yticks(np.arange(0,0.36,0.01), minor = True)
ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
ax1.set_xticks(np.arange(4,13.5,1), minor = False)
ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
ax1.set_yticks(np.arange(0,0.36,0.10), minor = False)
ax1.set_title(Title[0], loc='left', fontweight='bold')
ax1.set_ylabel('Fraction of time in $K$ classes', fontsize=fontsizeY)
ax1.set_xlabel('# classes', fontsize=fontsizeY)
ax1.set_xlim(4.5, 13.5)

width=width
ax2 = plt.subplot(1, 3, 2)
ax2.spines.right.set_visible(False)
ax2.spines.top.set_visible(False)
ax2.bar(data_2a_key, data_2a_value, width=width, color=color3, label='deaths')
ax2.bar(data_2b_key, data_2b_value, width=width, color=color1, label='births')
ax2.set_xlim(-3, 500)
ax2.tick_params(axis = 'y', which = 'minor', labelsize = 0)
ax2.set_yticks(np.arange(0,0.36,0.01), minor = True)
ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
ax2.set_xticks(np.arange(4,13.5,1), minor = False)
ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
ax2.set_yticks(np.arange(0,0.36,0.10), minor = False)
ax2.set_title(Title[1], loc='left', fontweight='bold')
ax2.set_xlabel('# classes', fontsize=fontsizeY)
ax2.set_ylabel('Fraction of events in $K$ classes', fontsize=fontsizeY)
ax2.legend(frameon=False, ncol=2, fontsize=fontticks, bbox_to_anchor=(1.0, 1.07))
ax2.set_xlim(4.5, 13.5)

ax3 = plt.subplot(1, 3, 3)
ax3.spines.right.set_visible(False)
ax3.spines.top.set_visible(False)
ax3.bar(data_3a_key, data_3a_value, width=width, color=color3, label='extinctions')
ax3.bar(data_3b_key, data_3b_value, width=width, color=color1, label='split')
ax3.tick_params(axis = 'y', which = 'minor', labelsize = 0)
ax3.set_yticks(np.arange(0,6.6,0.2), minor = True)
ax3.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
ax3.set_xticks(np.arange(4,13.5,1), minor = False)
ax3.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
ax3.set_yticks(np.arange(0,7.0,2), minor = False)
ax3.set_title(Title[2], loc='left', fontweight='bold')
ax3.set_xlabel('# classes', fontsize=fontsizeY)
ax3.set_ylabel('# events in $K$ classes / \n total time in $K$ classes '+r'$(\times 10^{-3})$', fontsize=fontsizeY)
ax3.set_xlim(4.5, 13.5)










#plt.tight_layout()
plt.savefig('./figures/Fig_4_ext_splt_statistics_ver_3.pdf', transparent=True)
plt.close()

print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
