#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys
import collections, pickle
from datetime import datetime
#from numba import jit
import pickle
from scipy.optimize import curve_fit
import matplotlib.ticker as mtick
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
#import matplotlib
from mpl_toolkits.axes_grid1.inset_locator import (inset_axes, InsetPosition, mark_inset, zoomed_inset_axes)
#matplotlib.use('ps')
#from matplotlib import rc
#rc('text',usetex=True)
#rc('text.latex', preamble='\usepackage{color}')
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)



x_lim_min = 3
x_lim_max = 14

directory = './split_stats'

with open(directory + '/n_gro_before_splt_slforig_rnase_slfmut_dict.pkl', 'rb') as input:
    n_gro_before_splt_slforig_rnase_slfmut_dict= pickle.load(input)
with open(directory + '/n_gro_before_splt_rnase_slfmut_slforig_dict.pkl', 'rb') as input:
    n_gro_before_splt_rnase_slfmut_slforig_dict= pickle.load(input)
with open(directory + '/n_gro_before_splt_rnase_slforig_slfmut_dict.pkl', 'rb') as input:
    n_gro_before_splt_rnase_slforig_slfmut_dict= pickle.load(input)
with open(directory + '/cum_t_n_gro_dict.pkl', 'rb') as input:
    cum_t_n_gro_dict = pickle.load(input)



n_gro_before_splt_slforig_rnase_slfmut_all_files_dict = {}
n_gro_before_splt_rnase_slfmut_slforig_all_files_dict = {}
n_gro_before_splt_rnase_slforig_slfmut_all_files_dict = {}
# n_gro_before_ext_all_files_dict = {}
# n_gro_before_splt_all_files_dict = {}
for n_gro in range(x_lim_min,x_lim_max):
    n_gro_before_splt_slforig_rnase_slfmut_all_files_dict[n_gro] = 0
    n_gro_before_splt_rnase_slfmut_slforig_all_files_dict[n_gro] = 0
    n_gro_before_splt_rnase_slforig_slfmut_all_files_dict[n_gro] = 0

for vals in n_gro_before_splt_slforig_rnase_slfmut_dict.values():
    for n_gro, num in vals.items():
        n_gro_before_splt_slforig_rnase_slfmut_all_files_dict[n_gro] += num

for vals in n_gro_before_splt_rnase_slfmut_slforig_dict.values():
    for n_gro, num in vals.items():
        n_gro_before_splt_rnase_slfmut_slforig_all_files_dict[n_gro] += num

for vals in n_gro_before_splt_rnase_slforig_slfmut_dict.values():
    for n_gro, num in vals.items():
        n_gro_before_splt_rnase_slforig_slfmut_all_files_dict[n_gro] += num




p_slforig_rnase_slfmut_given_k_gro = {}
p_rnase_slfmut_slforig_given_k_gro = {}
p_rnase_slforig_slfmut_given_k_gro = {}

p_slforig_rnase_slfmut_given_k_gro1 = {}
p_rnase_slfmut_slforig_given_k_gro1 = {}
p_rnase_slforig_slfmut_given_k_gro1 = {}


for n_gro in range(x_lim_min,x_lim_max):
    p_slforig_rnase_slfmut_given_k_gro1[n_gro] = n_gro_before_splt_slforig_rnase_slfmut_all_files_dict[n_gro]/ \
       np.sum(list(n_gro_before_splt_slforig_rnase_slfmut_all_files_dict.values()))/ \
       (cum_t_n_gro_dict[n_gro]/np.sum(list(cum_t_n_gro_dict.values())))
    p_rnase_slfmut_slforig_given_k_gro1[n_gro] = n_gro_before_splt_rnase_slfmut_slforig_all_files_dict[n_gro]/ \
        np.sum(list(n_gro_before_splt_rnase_slfmut_slforig_all_files_dict.values()))/ \
        (cum_t_n_gro_dict[n_gro]/np.sum(list(cum_t_n_gro_dict.values())))
    p_rnase_slforig_slfmut_given_k_gro1[n_gro] = n_gro_before_splt_rnase_slforig_slfmut_all_files_dict[n_gro] / \
        np.sum(list(n_gro_before_splt_rnase_slforig_slfmut_all_files_dict.values())) / \
        (cum_t_n_gro_dict[n_gro] / np.sum(list(cum_t_n_gro_dict.values())))
    if cum_t_n_gro_dict[n_gro] == 0:
        p_slforig_rnase_slfmut_given_k_gro[n_gro] = np.nan
        p_rnase_slfmut_slforig_given_k_gro1[n_gro] = np.nan
        cum_t_n_gro_dict[n_gro] = np.nan
    else:
        p_slforig_rnase_slfmut_given_k_gro[n_gro] = n_gro_before_splt_slforig_rnase_slfmut_all_files_dict[n_gro]/ \
            cum_t_n_gro_dict[n_gro]
        p_rnase_slfmut_slforig_given_k_gro[n_gro] = n_gro_before_splt_rnase_slfmut_slforig_all_files_dict[n_gro]/ \
            cum_t_n_gro_dict[n_gro]
        p_rnase_slforig_slfmut_given_k_gro[n_gro] = n_gro_before_splt_rnase_slforig_slfmut_all_files_dict[n_gro] / \
            cum_t_n_gro_dict[n_gro]







fig = plt.figure(figsize=(7.0,2.75))
plt.subplots_adjust(top=0.920, bottom=0.130, left=0.062, right=0.990, hspace=0.375, wspace=0.20)
fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 8, 9, 6.5, 8


Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
alpha_Color = 0.25
lw = 0.5; mW = 1.5; mS = 6
color1, color2, color3 = 'g', 'b', 'r'

width=0.2


ax1 = plt.subplot(1, 2, 1)
ax1.spines.right.set_visible(False)
ax1.spines.top.set_visible(False)

ax1.bar(np.array(list(n_gro_before_splt_rnase_slfmut_slforig_all_files_dict.keys()))-width,
        list(n_gro_before_splt_rnase_slfmut_slforig_all_files_dict.values())/ \
        np.sum(list(n_gro_before_splt_rnase_slfmut_slforig_all_files_dict.values())),
         color = 'g', width = width) #log=True, #/np.sum(list(dt_dict.values()))/10,
ax1.bar(np.array(list(n_gro_before_splt_rnase_slforig_slfmut_all_files_dict.keys())) ,
        list(n_gro_before_splt_rnase_slforig_slfmut_all_files_dict.values())/ \
        np.sum(list(n_gro_before_splt_rnase_slforig_slfmut_all_files_dict.values())),
         color = 'b', width = width)
ax1.bar(np.array(list(n_gro_before_splt_slforig_rnase_slfmut_all_files_dict.keys()))+width,
        list(n_gro_before_splt_slforig_rnase_slfmut_all_files_dict.values())/ \
       np.sum(list(n_gro_before_splt_slforig_rnase_slfmut_all_files_dict.values())),
         color = 'r', width = width) #log=True, #/np.sum(list(dt_dict.values()))/10,

ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
ax1.set_xticks(list(n_gro_before_splt_slforig_rnase_slfmut_all_files_dict.keys()), minor = False)
ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
ax1.set_yticks(np.arange(0.0,0.45,0.1), minor = False)
ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
ax1.set_yticks(np.arange(0.0,0.452,0.02), minor = True)
ax1.set_xlim(x_lim_min+1.25, x_lim_max-1.75)
ax1.set_ylabel('Fraction of events in $K$ classes', fontsize=fontsizeY)
ax1.set_xlabel('# classes', fontsize=fontsizeX)
ax1.set_title(Title[0], loc='left', fontweight='bold')
ax1.legend([r'$\mathrm{RNase} \rightarrow \mathrm{SLF}_{\mathrm{mut}} \rightarrow \mathrm{SLF}_{\mathrm{orig}}$', \
            r'$\mathrm{RNase} \rightarrow \mathrm{SLF}_{\mathrm{orig}} \rightarrow \mathrm{SLF}_{\mathrm{mut}}$', \
            r'$\mathrm{SLF}_{\mathrm{orig}} \rightarrow \mathrm{RNase} \rightarrow \mathrm{SLF}_{\mathrm{mut}}$'], \
            frameon=False, loc=2, fontsize=fontticks-0.5, ncol=2)






ax1 = plt.subplot(1, 2, 2)
ax1.spines.right.set_visible(False)
ax1.spines.top.set_visible(False)

print (np.arange(x_lim_min+2,x_lim_max))
print (np.array(list(p_rnase_slfmut_slforig_given_k_gro.values()))*1000)

ax1.bar(np.arange(x_lim_min+2,x_lim_max)-width, np.array(list(p_rnase_slfmut_slforig_given_k_gro.values()))*1000,
         color = 'g', width = width, label = r'$RNase\rightarrow SLF_{mut}\rightarrow SLF_{orig}$') #log=True, #/np.sum(list(dt_dict.values()))/10,
ax1.bar(np.arange(x_lim_min+2,x_lim_max), np.array(list(p_rnase_slforig_slfmut_given_k_gro.values()))*1000,
         color = 'b', width = width, label = r'$RNase\rightarrow SLF_{orig}\rightarrow SLF_{mut}$')
ax1.bar(np.arange(x_lim_min,x_lim_max)+width, np.array(list(p_slforig_rnase_slfmut_given_k_gro.values()))*1000,
         color = 'r', width = width, label = r'$SLF_{orig} \rightarrow RNase\rightarrow SLF_{mut}$') #log=True, #/np.sum(list(dt_dict.values()))/10,

ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
ax1.set_xticks(list(n_gro_before_splt_slforig_rnase_slfmut_all_files_dict.keys()), minor = False)
ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
ax1.set_yticks(np.arange(0.0,0.40,0.1), minor = False)
ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
ax1.set_yticks(np.arange(0.0,0.37,0.05/2), minor = True)
ax1.set_xlim(x_lim_min+1.25, x_lim_max-1.75)
ax1.set_ylabel('# events in K classes / total time in \n$K$ classes'+r'$(\times ~10^{-3})$', fontsize=fontsizeY)
ax1.set_xlabel('# classes', fontsize=fontsizeX)
ax1.set_title(Title[1], loc='left', fontweight='bold')



#plt.tight_layout()
plt.savefig('../SI_figures/Fig_splt_statistics_all_trajs_Eminus6.pdf', transparent=True)
plt.close()

print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
