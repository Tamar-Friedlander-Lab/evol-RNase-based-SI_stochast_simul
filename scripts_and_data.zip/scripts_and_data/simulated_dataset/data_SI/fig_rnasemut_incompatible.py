#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys
import collections, pickle
from datetime import datetime
#from numba import jit
import pickle
from scipy.optimize import curve_fit
import matplotlib.ticker as mtick
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)


data = {0:15700, 1:1467, 2:252, 3:17, 4:1, 5:1}

data_Y = np.array(list(data.values()))
data_X = np.arange(0, len(data_Y), 1)

for i in range(6):
    print ('%0.4f' % (np.round(data_Y/sum(data_Y), 4)[i]))


fig = plt.figure(figsize=(5.25,3.75))
plt.subplots_adjust(top=0.995, bottom=0.10, left=0.122, right=0.990, hspace=0.375, wspace=0.45)
fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 10, 9, 6.5, 8


Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
alpha_Color = 0.25
lw = 0.5; mW = 1.5; mS = 6
color1, color2, color3 = 'g', 'b', 'r'

ax1 = plt.subplot(1, 1, 1)
ax1.spines.right.set_visible(False)
ax1.spines.top.set_visible(False)
width = 0.5
ax1.bar(data_X, data_Y/sum(data_Y), width = width)
ax1.set_yscale('log')
ax1.set_xlabel(r'$K$ classes', fontsize=fontsizeY)
ax1.set_ylabel('Fraction of RNase mutations incompatible with \n' + r'non-self $K$ classes', fontsize=fontsizeX)
ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
ax1.set_yticks([0.0001, 0.001, 0.01, 0.1, 1.0], minor = False)
#ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
#ax1.set_yticks(np.arange(0,0.9,0.05), minor = True)
ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
ax1.set_xticks(np.arange(0,6,1), minor = False)

#plt.tight_layout()
plt.savefig('../SI_figures/Fig_rnasemut_incompatible.pdf', transparent=True)
#plt.show()
plt.close()

print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
