#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys
import collections, pickle
from datetime import datetime
#from numba import jit
import pickle
from scipy.optimize import curve_fit
import matplotlib.ticker as mtick
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
#import matplotlib
from mpl_toolkits.axes_grid1.inset_locator import (inset_axes, InsetPosition, mark_inset, zoomed_inset_axes)
#matplotlib.use('ps')
#from matplotlib import rc
#rc('text',usetex=True)
#rc('text.latex', preamble='\usepackage{color}')
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)

non_classified = pickle.load(open('./unclassified_hap/num_SC_haps_all_iters_all_files_E-6_N500_a095_d_1.pkl', 'rb'))
print (type(non_classified), len(non_classified))

Mean = []
Std = []
full_data = []
for ele in non_classified:
    full_data.extend(ele)
    if len(ele) > 0:
        Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
        Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))


#print (np.round(np.mean(np.array(Mean)), decimals=2))
#print (np.round(np.std(np.array(Std)), decimals=2))

full_data = np.array(full_data)

print (np.array(Mean))
print (np.array(Std))

Avg = np.round(np.mean(full_data/1000), decimals=3)
STD = np.round(np.std(full_data/1000), decimals=3)
#print (Avg, STD)


data_X, data_Y = np.unique(full_data, return_counts=True)
print (data_X, data_Y)
#print (list(data_X).index(100), np.cumsum(data_Y/sum(data_Y))[100])

fig = plt.figure(figsize=(7.0,2.75))
plt.subplots_adjust(top=0.920, bottom=0.135, left=0.064, right=0.990, hspace=0.375, wspace=0.20)
fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 10, 9, 6.5, 8


Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
alpha_Color = 0.25
lw = 0.5; mW = 1.5; mS = 6
color1, color2, color3 = 'g', 'b', 'r'



ax1 = plt.subplot(1, 2, 1)
ax1.spines.right.set_visible(False)
ax1.spines.top.set_visible(False)
width = 0.50
ax1.plot(data_X/1000, data_Y*100/sum(data_Y))
ax1.vlines(np.mean(full_data)/1000, 0, 17, linestyle='dashed', color='r')
#ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
#ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
ax1.set_xlabel('Fraction of SC haplotypes', fontsize=fontsizeX)
ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
ax1.set_yticks(np.arange(0.0,20.0,5.0), minor = False)
ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
ax1.set_yticks(np.arange(0,20.0,1.0), minor = True)
ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
ax1.set_xticks(np.arange(0,0.045,0.01), minor = False)
ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
ax1.set_xticks(np.arange(0,0.046,0.005/2), minor = True)
ax1.set_xlim(-0.0005,0.045)
ax1.set_ylim(-0.2, 18.05)
ax1.text(Avg+0.001/2, 1.0, Avg, fontsize=fontsizeX-1, color='r')
ax1.set_title(Title[0], loc='left', fontweight='bold')



ax2 = inset_axes(ax1, 1.8, 1.15 , loc=1, bbox_to_anchor=(0.49, 0.95),bbox_transform=ax1.figure.transFigure)
ax2.spines.right.set_visible(False)
ax2.spines.top.set_visible(False)
ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
ax2.set_yticks(np.arange(0.0,1.01,0.2), minor = False)
ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
ax2.set_yticks(np.arange(0,1.01,0.1/2), minor = True)
ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
ax2.set_xticks(np.arange(0,0.046,0.01), minor = False)
ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
ax2.set_xticks(np.arange(0,0.046,0.01/2), minor = True)
ax2.set_xlim(-0.0005,0.045)
ax2.set_ylim(-0.015, 1.015)
ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
#ax2.vlines(0.1, 0, 0.95, linestyle='dashed', color='k')
#ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
#ax2.text(0.115, 0.83, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-1)
ax2.set_ylabel(r'CDF', fontsize=fontsizeY-1)













non_classified = pickle.load(open('./unclassified_hap/n_non_class_hap_all_iters_all_files_E-6.pkl', 'rb'))
print (type(non_classified), len(non_classified))

Mean = []
Std = []
full_data = []
for ele in non_classified:
    full_data.extend(ele)
    if len(ele) > 0:
        Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
        Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))


#print (np.round(np.mean(np.array(Mean)), decimals=2))
#print (np.round(np.std(np.array(Std)), decimals=2))

full_data = np.array(full_data)

print (np.array(Mean))
print (np.array(Std))

Avg = np.round(np.mean(full_data/1000), decimals=3)
STD = np.round(np.std(full_data/1000), decimals=3)

print (Avg, STD)


data_X, data_Y = np.unique(full_data, return_counts=True)
print (list(data_X).index(100), np.cumsum(data_Y/sum(data_Y))[100])


ax1 = plt.subplot(1, 2, 2)
ax1.spines.right.set_visible(False)
ax1.spines.top.set_visible(False)
width = 0.50
ax1.plot(data_X/1000, data_Y*100/sum(data_Y))
ax1.vlines(np.mean(full_data)/1000, 0, 1.5, linestyle='dashed', color='r')
#ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
#ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
ax1.set_xlabel('Fraction of unclassified haplotypes', fontsize=fontsizeX)
ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
ax1.set_yticks(np.arange(0.0,2.05,0.5), minor = False)
ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
ax1.set_yticks(np.arange(0,2.05,0.1), minor = True)
ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
ax1.set_xticks(np.arange(0,0.50,0.1), minor = False)
ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
ax1.set_xticks(np.arange(0,0.50,0.01), minor = True)
ax1.set_xlim(-0.005,0.47)
ax1.set_ylim(-0.015, 2.05)
ax1.text(Avg-0.01, 1.55, Avg, fontsize=fontsizeX-1, color='r')
ax1.set_title(Title[1], loc='left', fontweight='bold')



ax2 = inset_axes(ax1, 1.8, 1.15 , loc=1, bbox_to_anchor=(0.99, 0.95),bbox_transform=ax1.figure.transFigure)
ax2.spines.right.set_visible(False)
ax2.spines.top.set_visible(False)
ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
ax2.set_yticks(np.arange(0.0,1.01,0.2), minor = False)
ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
ax2.set_yticks(np.arange(0,1.01,0.1/2), minor = True)
ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
ax2.set_xticks(np.arange(0,0.50,0.1), minor = False)
ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
ax2.set_xticks(np.arange(0,0.50,0.02), minor = True)
ax2.set_xlim(-0.005,0.47)
ax2.set_ylim(-0.015, 1.015)
ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
ax2.vlines(0.1, 0, 0.95, linestyle='dashed', color='k')
#ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
ax2.text(0.115, 0.83, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-1)
ax2.set_ylabel(r'CDF', fontsize=fontsizeY)

#plt.tight_layout()
plt.savefig('../SI_figures/Fig_unclassicfied_hap.pdf', transparent=True)
plt.close()

print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
