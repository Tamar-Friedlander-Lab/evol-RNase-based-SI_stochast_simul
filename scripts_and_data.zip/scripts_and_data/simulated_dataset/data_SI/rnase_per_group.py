#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys
import collections, pickle
from datetime import datetime
#from numba import jit
import pickle
from scipy.optimize import curve_fit
import matplotlib.ticker as mtick
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
#import matplotlib
from mpl_toolkits.axes_grid1.inset_locator import (inset_axes, InsetPosition, mark_inset, zoomed_inset_axes)
#matplotlib.use('ps')
#from matplotlib import rc
#rc('text',usetex=True)
#rc('text.latex', preamble='\usepackage{color}')
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)

incom_rnase_per_group_size = pickle.load(open('./rnase_per_group_size/norm_num_noncomp_mutRNase_all_exts.pkl', 'rb'))
incom_rnase_per_group_size = np.round(incom_rnase_per_group_size, 5)
keys, values = np.unique(incom_rnase_per_group_size, return_counts=True)
#print (keys, values)
#print (type(incom_rnase_per_group_size), len(incom_rnase_per_group_size), incom_rnase_per_group_size)

def bin_Control(input_Var, no_bins, density):
    data_X, data_Y = input_Var[:,0], input_Var[:,1]
    density_State = density # 1 means PDF, 0 means PMF

    Check_Bin = np.linspace(min(input_Var[:,0]),max(input_Var[:,0])+0.001,no_bins+1)
    output_Bin_Data = np.zeros(len(Check_Bin)-1)

    for bin1, bin2, index in zip(Check_Bin[:-1], Check_Bin[1:], range(len(Check_Bin[1:]))):
        current_Bin_Data = [Value for Key, Value in zip(data_X, data_Y) if Key >= bin1 and Key < bin2]
        if density_State == 1:
            if len(current_Bin_Data) > 0:
                output_Bin_Data[index] = sum(current_Bin_Data)/float(len(current_Bin_Data))
            else:
                output_Bin_Data[index] = sum(current_Bin_Data)
        if density_State == 0:
            output_Bin_Data[index] = sum(current_Bin_Data)

    frequency = np.array(output_Bin_Data)/sum(output_Bin_Data)
    center_bin = (Check_Bin[:-1]+Check_Bin[1:])/2

    return center_bin, frequency, (max(input_Var[:,0]) - min(input_Var[:,0]))/no_bins

no_bins, density = 40, 0
input_Var = np.concatenate(([keys], [values])).T
data_X, data_Y, binSize = bin_Control(input_Var, no_bins, density)
avg, std = np.mean(incom_rnase_per_group_size), np.std(incom_rnase_per_group_size)
print (data_X, data_Y, binSize, avg, std)


fig = plt.figure(figsize=(4.0,2.75))
plt.subplots_adjust(top=0.995, bottom=0.135, left=0.124, right=0.990, hspace=0.375, wspace=0.20)
fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 10, 9, 6.5, 8


Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
alpha_Color = 0.25
lw = 0.5; mW = 1.5; mS = 6
color1, color2, color3 = 'g', 'b', 'r'



ax1 = plt.subplot(1, 1, 1)
ax1.spines.right.set_visible(False)
ax1.spines.top.set_visible(False)
width = 0.50
ax1.bar(data_X[1:], data_Y[1:], width=binSize*0.75)
ax1.set_ylabel(r'Frequency', fontsize=fontsizeY)
ax1.set_xlabel('# incompatible RNase copies / mean class size', fontsize=fontsizeX)
ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
ax1.set_yticks(np.arange(0.0,0.12,0.02), minor = False)
ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
ax1.set_yticks(np.arange(0.0,0.12,0.02/4), minor = True)
ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
ax1.set_xticks(np.arange(0,1.8,0.5), minor = False)
ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
ax1.set_xticks(np.arange(0,1.81,0.5/5), minor = True)
ax1.set_xlim(-0.02,1.85)
ax1.set_ylim(-0., 0.12)
ax1.vlines(avg, 0, 0.115, linestyle='dashed', color='r')#ax1.set_title(Title[0], loc='left', fontweight='bold')
ax1.text(avg*1.05, 0.11, np.round(avg, 2), color = 'r', fontsize=fontsizeX-2)

#plt.tight_layout()
plt.savefig('../SI_figures/Fig_incom_rnase_per_group_size.pdf', transparent=True)
#plt.show()
plt.close()

print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
